// Recursion, loops and function calls
int fact(int n) {
    if (n <= 1) return 1;
    return n * fact(n - 1);
}

int factLoop(int n) {
    int result = 1;
    for (int i = 2; i <= n; i = i + 1) {
        result = result * i;
    }
    return result;
}

int main() {
    for (int i = 0; i <= 7; i = i + 1) {
        print("fact(", i, ") = ", fact(i), "   loop: ", factLoop(i));
    }
    return 0;
}
