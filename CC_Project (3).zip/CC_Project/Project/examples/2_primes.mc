// bool functions, while loops, && and %
bool isPrime(int n) {
    if (n < 2) return false;
    int d = 2;
    while (d * d <= n) {
        if (n % d == 0) return false;
        d = d + 1;
    }
    return true;
}

int gcd(int a, int b) {
    while (b != 0) {
        int t = a % b;
        a = b;
        b = t;
    }
    return a;
}

int main() {
    int count = 0;
    for (int n = 1; n <= 30; n = n + 1) {
        if (isPrime(n)) {
            print(n, " is prime");
            count = count + 1;
        }
    }
    print("primes up to 30: ", count);
    print("is 97 prime? ", isPrime(97), "   is 91 prime? ", isPrime(91));
    print("gcd(84, 36) = ", gcd(84, 36));
    print("even and > 10: ", count % 2 == 0 && count > 10);
    return 0;
}
