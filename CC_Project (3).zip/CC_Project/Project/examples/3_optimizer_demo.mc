// Compare "TAC" with "Optimized TAC" to see what the optimizer removes
int main() {
    int a = 4 * 5 + 2;        // constant folding: becomes 22
    int b = a;                // copy propagation
    int c = b * 1 + 0;        // algebraic simplification
    int unused = a * 100;     // dead code: never read
    bool debug = false;
    if (debug) {              // condition known at compile time: branch removed
        print("this branch is removed");
    }
    while (false) {
        print("never runs");
    }
    print("c = ", c);
    int x = 10;
    int y = x - 3;
    print("y = ", y, ", a > y is ", a > y);
    return 0;
}
