// The parser reports every syntax error, not just the first one
int main() {
    int x = 10
    int y = (x + 5;
    if x > 3) { print(x); }
    y = x * ;
    return 0;
}
