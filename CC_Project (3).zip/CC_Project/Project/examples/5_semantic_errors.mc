// Semantic analysis: undeclared names, wrong types, wrong function calls
int square(int n) {
    return n * n;
}

void greet() {
    print("hello");
}

int main() {
    int x = 5;
    bool ok = x;              // int stored in a bool
    y = 10;                   // undeclared variable
    int x = 3;                // declared twice
    int s = square(1, 2);     // wrong number of arguments
    s = square(true);         // wrong argument type
    int g = greet();          // void function used as a value
    s = cube(3);              // undeclared function
    if (x) print(x);          // condition must be bool
    return ok;                // wrong return type
}
